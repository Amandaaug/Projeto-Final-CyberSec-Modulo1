# Modulo1 Fundamentos

Fundamentos de Cyber - Conceitos básicos, CIA, ameaças, ataques, redes, Kali Linux, nmap, wireshark.
