# Modulo2 Defesa Monitoramento

Defesa e Monitoramento – Segurança em sistemas, infraestrutura, cloud e resposta a incidentes.
